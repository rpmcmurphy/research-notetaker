<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TjAc4hZZKZW5dQ1g',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MIgWbIkqjsWejfrG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/topic-list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pU6ml16lyJeqsE7n',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/topic-list-react-select' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DDjbeFVVg1IPsR1A',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/topic-add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ch33sjOLZ7poREHs',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/topic-update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ti3LwQ7a4F0FqbS9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/detail-add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ORDlspfQoPKBoa8s',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/detail-update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::seCvW7gVXjmO0BLG',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/delete-file' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XzuBsjQHfLXqX35f',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/search-result' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xUwoHtQdZ5ML6aYn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/test-file-upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ONyZ1vdWAJucP57e',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/(?|topic(?|\\-(?|list(?:/([^/]++))?(*:46)|delete/([^/]++)(*:68))|/([^/]++)(*:85))|detail(?|\\-(?|list(?:/([^/]++))?(*:125)|delete/([^/]++)(*:148))|/([^/]++)(*:166)))|/((?:[A-z\\d\\-\\/_.]+)?)(*:198))/?$}sDu',
    ),
    3 => 
    array (
      46 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9f5pGKiw4VXqlU8Y',
            'page_num' => NULL,
          ),
          1 => 
          array (
            0 => 'page_num',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      68 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oa0BuPTfR7t3Kxky',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      85 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QCSDqu6vaefpwc61',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      125 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::64OpHwB8OHO3qEiV',
            'page_num' => NULL,
          ),
          1 => 
          array (
            0 => 'page_num',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      148 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jdOkVUvTMnjpzwLp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      166 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2cB9gHKSoGQJmvIe',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      198 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qjd0cqp5SsLL9otj',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::TjAc4hZZKZW5dQ1g' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::TjAc4hZZKZW5dQ1g',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MIgWbIkqjsWejfrG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc473800000000493a0c86";}";s:4:"hash";s:44:"ndHxOE/PshUb9WMOSYn5eWQ1c8YO0IYbyFXRxzgbunQ=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::MIgWbIkqjsWejfrG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pU6ml16lyJeqsE7n' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/topic-list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:476:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:257:"function () {

    // get all topic ID and name, and sort by name
    $topic_list = \\App\\Models\\Topic::select(\'id\', \'name\')->orderBy(\'name\')->get();

    return \\response()->json([
        \'data\' => $topic_list,
        \'status\' => \'success\',
    ], 200);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc473900000000493a0c86";}";s:4:"hash";s:44:"aKN6Pck9Pp3J7iR+BxCe9z1m10zaxeJV5oWFu/tQ7xY=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::pU6ml16lyJeqsE7n',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DDjbeFVVg1IPsR1A' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/topic-list-react-select',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:496:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:277:"function () {

    // get all topic ID and name, and sort by name
    $topic_list = \\App\\Models\\Topic::select([\'id AS value\', \'name AS label\'])->orderBy(\'name\')->get();

    return \\response()->json([
        \'data\' => $topic_list,
        \'status\' => \'success\',
    ], 200);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc473d00000000493a0c86";}";s:4:"hash";s:44:"KUNxSv2iOlByMHuLPvP/TtwT1RYBis25zH95ji/UzHw=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::DDjbeFVVg1IPsR1A',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9f5pGKiw4VXqlU8Y' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/topic-list/{page_num?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:465:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:246:"function ($page_num = 1) {

    $topic_list = \\App\\Models\\Topic::orderBy(\'name\', \'asc\')->paginate(10, [\'id\', \'name\'], \'page\', $page_num);

    return \\response()->json([
        \'data\' => $topic_list,
        \'status\' => \'success\',
    ], 200);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc473300000000493a0c86";}";s:4:"hash";s:44:"OAHfwBKdzmrVO1aRHQcM8k+v79M6HfDXGcbnavUISFI=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::9f5pGKiw4VXqlU8Y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QCSDqu6vaefpwc61' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/topic/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:407:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:188:"function ($id) {
    $topic = \\App\\Models\\Topic::where(\'id\', $id)
        ->first();

    return \\response()->json([
        \'data\' => $topic,
        \'status\' => \'success\',
    ], 200);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc473100000000493a0c86";}";s:4:"hash";s:44:"+u8OcsmYUni37Un9y7OMPdH9Zx1KpLnpzewuA6eZQJ4=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::QCSDqu6vaefpwc61',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ch33sjOLZ7poREHs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/topic-add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:1401:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1181:"function (\\Illuminate\\Http\\Request $request) {

    $validator = \\Illuminate\\Support\\Facades\\Validator::make($request->all(), [
        \'topic_name\' => \'required|min:3\',
    ]);

    if ($validator->fails()) {

        $message = $validator->errors();

        return \\response()->json([
            \'status\' => \'error\',
            \'message\' => $message
        ], 200);
    }

    // Find if topic name already exists
    $topic_name = $request->input(\'topic_name\');
    $topic_exists = \\App\\Models\\Topic::where(\'name\', $topic_name)->first();

    if ($topic_exists) {
        return \\response()->json([
            \'status\' => \'error\',
            \'message\' => \'Topic name already exists!\'
        ], 200);
    }

    $topic = new \\App\\Models\\Topic();
    $topic->name = $request->topic_name;
    $topic->save();

    if ($topic) {
        return \\response()->json([
            \'data\' => $topic,
            \'status\' => \'success\',
            \'message\' => \'Topic successfully created.\',
        ], 200);
    } else {
        return \\response()->json([
            \'status\' => \'error\',
            \'message\' => \'Something went wrong. Please try again.\',
        ], 200);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc473700000000493a0c86";}";s:4:"hash";s:44:"wc/tABiHJ+7WPNNLIJDTigGe/fZPmuVilBptz1HOUKI=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Ch33sjOLZ7poREHs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ti3LwQ7a4F0FqbS9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/topic-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:1456:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1236:"function (\\Illuminate\\Http\\Request $request) {

    $validator = \\Illuminate\\Support\\Facades\\Validator::make($request->all(), [
        \'id\' => \'required\',
        \'topic_name\' => \'required|min:3\',
    ]);

    if ($validator->fails()) {

        $message = $validator->errors();

        return \\response()->json([
            \'status\' => \'error\',
            \'message\' => $message
        ], 200);
    }

    // Find if topic name already exists
    $topic_name = $request->topic_name;
    $topic_exists = \\App\\Models\\Topic::where(\'name\', $topic_name)->first();

    if ($topic_exists) {
        return \\response()->json([
            \'status\' => \'error\',
            \'message\' => \'Topic name already exists!\'
        ], 200);
    }

    $topic = \\App\\Models\\Topic::where(\'id\', $request->id)->firstOrFail();
    $topic->name = $request->topic_name;
    $topic->save();

    if ($topic) {
        return \\response()->json([
            \'data\' => $topic,
            \'status\' => \'success\',
            \'message\' => \'Topic successfully updated.\',
        ], 200);
    } else {
        return \\response()->json([
            \'status\' => \'error\',
            \'message\' => \'Something went wrong. Please try again.\',
        ], 200);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc473500000000493a0c86";}";s:4:"hash";s:44:"fxGJ0sBlsAQ8r7blpqG8M17y7rZqqr3wr7BXE3ZM6mk=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ti3LwQ7a4F0FqbS9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oa0BuPTfR7t3Kxky' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/topic-delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:656:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:437:"function ($id) {

    $topic = \\App\\Models\\Topic::where(\'id\', $id)->firstOrFail();

    $topic->delete();

    if ($topic) {
        return \\response()->json([
            \'status\' => \'success\',
            \'message\' => \'Topic has been deleted.\',
        ], 200);
    } else {
        return \\response()->json([
            \'status\' => \'error\',
            \'message\' => \'Something went wrong. Please try again.\',
        ], 200);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc472b00000000493a0c86";}";s:4:"hash";s:44:"zZwU9vV8T7X1FyT6lUKxuJGPUH+SPv6Lm4j14B22oS4=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::oa0BuPTfR7t3Kxky',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::64OpHwB8OHO3qEiV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/detail-list/{page_num?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:641:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:422:"function ($page_num = 1) {

    $details_list = \\App\\Models\\Detail::query()
        ->with([\'topics\' => function ($query) {
            $query->select(\'id\', \'name\');
        }])
        ->orderBy(\'created_at\', \'desc\')
        ->paginate(10, [\'id\', \'details_name\', \'details\', \'files_images\'], \'page\', $page_num);

    return \\response()->json([
        \'data\' => $details_list,
        \'status\' => \'success\',
    ], 200);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc472900000000493a0c86";}";s:4:"hash";s:44:"6Oq1oFrb9OJYZgPFYqP2Ejaa/RPWf4J7tMtjbXt7CCw=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::64OpHwB8OHO3qEiV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2cB9gHKSoGQJmvIe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/detail/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:521:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:302:"function($id) {
    $detail = \\App\\Models\\Detail::query()
        ->with([\'topics\' => function ($query) {
            $query->select(\'id\');
        }])
        ->where(\'id\', $id)
        ->first();

    return \\response()->json([
        \'data\' => $detail,
        \'status\' => \'success\',
    ], 200);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc472f00000000493a0c86";}";s:4:"hash";s:44:"Softm/3KswgTRbpXFvwnqRKnuH8zLKuiSsFvTASc1/s=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::2cB9gHKSoGQJmvIe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ORDlspfQoPKBoa8s' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/detail-add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:2770:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:2550:"function(\\Illuminate\\Http\\Request $request) {

    $validator = \\Illuminate\\Support\\Facades\\Validator::make($request->all(), [
        \'details_name\' => \'required|min:3\',
        \'details\' => \'required|min:3\'
    ]);

    if ($validator->fails()) {

        $message = $validator->errors();

        return \\response()->json([
            \'status\' => \'error\',
            \'type\' => \'validation\',
            \'message\' => \\Illuminate\\Support\\Arr::flatten($message->all())
        ], 200);
    }

    // Find if details name already exists
    $details_name = $request->details_name;
    $details_exists = \\App\\Models\\Detail::where(\'details_name\', $details_name)->first();

    if ($details_exists) {
        return \\response()->json([
            \'status\' => \'error\',
            \'message\' => \'Details name already exists!\'
        ], 200);
    }

    $details = new \\App\\Models\\Detail();

    $details->details_name = $request->details_name;
    $details->details = $request->details;

    if ($request->hasFile(\'files_images\')) {

        $allowedfileExtension = [\'pdf\', \'jpg\', \'png\', \'gif\', \'bmp\', \'docx\'];
        $files = $request->file(\'files_images\');

        foreach ($files as $file) {
            $filename = $file->getClientOriginalName();
            $extension = $file->getClientOriginalExtension();
            $check = \\in_array($extension, $allowedfileExtension);
            $filename_without_ext = \\pathinfo($filename, PATHINFO_FILENAME);

            if ($check) {
                $filename = $file->storeAs(\'files_images\', $filename_without_ext . \'_\' . \\Illuminate\\Support\\Str::random(5) . \'.\' .  $extension, \'public\');
                if ($filename) {
                    $stored_filenames[] = $filename;
                }
            } else {
                return \\response()->json([
                    \'status\' => \'error\',
                    \'message\' => \'File extension not allowed.\',
                ], 200);
            }
        }

        $details->files_images = \\json_encode($stored_filenames);
    }

    $details->save();

    $created_detail = \\App\\Models\\Detail::find($details->id);
    $created_detail->topics()->attach($request->topic_ids);

    if($details) {
        return \\response()->json([
            \'data\' => $details,
            \'message\' => \'Detail created successfully!\',
            \'status\' => \'success\',
        ], 200);
    } else {
        return \\response()->json([
            \'status\' => \'error\',
            \'message\' => \'Something went wrong. Please try again.\',
        ], 200);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc472d00000000493a0c86";}";s:4:"hash";s:44:"dmxZVVnDFlAB/8WdzmZhr7AejifDtsexdNgtuExvZ4Y=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ORDlspfQoPKBoa8s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::seCvW7gVXjmO0BLG' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/detail-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:2727:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:2507:"function (\\Illuminate\\Http\\Request $request) {

    $validator = \\Illuminate\\Support\\Facades\\Validator::make($request->all(), [
        \'details_name\' => \'required|min:3\',
        \'details\' => \'required|min:3\'
    ]);

    if ($validator->fails()) {

        $message = $validator->errors();

        return \\response()->json([
            \'status\' => \'error\',
            \'message\' => $message
        ], 200);
    }

    // Find if details name already exists
    $details_name = $request->details_name;
    $details_exists = \\App\\Models\\Detail::where(\'details_name\', $details_name)->where(\'id\', \'!=\', $request->id)->first();

    if ($details_exists) {
        return \\response()->json([
            \'status\' => \'error\',
            \'message\' => \'Details name already exists!\'
        ], 200);
    }

    $details = \\App\\Models\\Detail::where(\'id\', $request->id)->firstOrFail();

    $details->details_name = $request->details_name;
    $details->details = $request->details;

    if ($request->hasFile(\'files_images\')) {

        $allowedfileExtension = [\'pdf\', \'jpg\', \'png\', \'gif\', \'bmp\', \'docx\', \'txt\'];
        $files = $request->file(\'files_images\');

        foreach ($files as $file) {
            $filename = $file->getClientOriginalName();
            $extension = $file->getClientOriginalExtension();
            $check = \\in_array($extension, $allowedfileExtension);
            $filename_without_ext = \\pathinfo($filename, PATHINFO_FILENAME);

            if ($check) {
                $filename = $file->storeAs(\'files_images\', $filename_without_ext . \'_\' . \\Illuminate\\Support\\Str::random(5) . \'.\' .  $extension, \'public\');
                if ($filename) {
                    $stored_filenames[] = $filename;
                }
            } else {
                return \\response()->json([
                    \'status\' => \'error\',
                    \'message\' => \'File extension not allowed.\',
                ], 200);
            }
        }

        $details->files_images = \\json_encode($stored_filenames);
    }

    $details->save();

    $created_detail = \\App\\Models\\Detail::find($details->id);
    $created_detail->topics()->sync(\\explode(\',\', $request->topic_ids));

    if ($details) {
        return \\response()->json([
            \'data\' => $details,
            \'status\' => \'success\',
        ], 200);
    } else {
        return \\response()->json([
            \'status\' => \'error\',
            \'message\' => \'Something went wrong. Please try again.\',
        ], 200);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc472300000000493a0c86";}";s:4:"hash";s:44:"GH7EeLOh+9TDMnYj6Kt2HGx+MB9wpUT/9ex3juNyY8g=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::seCvW7gVXjmO0BLG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XzuBsjQHfLXqX35f' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/delete-file',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:1581:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1361:"function(\\Illuminate\\Http\\Request $request) {

    $detail_id = $request->detail_id;
    $file_link = $request->file_link;

    $details = \\App\\Models\\Detail::where(\'id\', $detail_id)->firstOrFail();

    $files_images = \\json_decode($details->files_images);

    $key = \\array_search($file_link, $files_images);

    if ($key !== false) {
        unset($files_images[$key]);
    }

    foreach ($files_images as $file) {
        $updated_file_paths[] = $file;
    }

    $details->files_images = (isset($updated_file_paths) && !empty($updated_file_paths)) ? \\json_encode($updated_file_paths) : null;
    $details->save();

    if ($details) {

        $full_image_path = \\public_path(\'storage/\' . $file_link);

        if (\\Illuminate\\Support\\Facades\\File::exists($full_image_path)) {
            \\Illuminate\\Support\\Facades\\File::delete($full_image_path);

            return \\response()->json([
                \'error\' => false,
                \'message\'  => \'Your file has been deleted.\',
            ], 200);
        } else {
            return \\response()->json([
                \'error\' => true,
                \'message\'  => \'Your file has not been deleted.\',
            ], 200);
        }
    } else {

        return \\response()->json([
            \'error\' => true,
            \'message\'  => \'Your file has not been deleted.\',
        ], 200);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc472100000000493a0c86";}";s:4:"hash";s:44:"oWiwQGBZfFILIJQ2fNe3HHO5kYzeXFZ66sbyIASch8c=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::XzuBsjQHfLXqX35f',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jdOkVUvTMnjpzwLp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/detail-delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:663:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:444:"function($id) {

    $details = \\App\\Models\\Detail::where(\'id\', $id)->firstOrFail();

    $details->delete();

    if ($details) {
        return \\response()->json([
            \'status\' => \'success\',
            \'message\' => \'Detail has been deleted.\',
        ], 200);
    } else {
        return \\response()->json([
            \'status\' => \'error\',
            \'message\' => \'Something went wrong. Please try again.\',
        ], 200);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc472700000000493a0c86";}";s:4:"hash";s:44:"pKlc9fPtv8TsjygHZbJC7cJdPB+P6xgXP6qhInpHCL8=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::jdOkVUvTMnjpzwLp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xUwoHtQdZ5ML6aYn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/search-result',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:1365:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1145:"function(\\Illuminate\\Http\\Request $request) {

    $term = $request->searchTerm;
    $topic_id = $request->topicId;

    $topics = \\App\\Models\\Topic::all();
    $details = \\App\\Models\\Detail::with([\'topics\'])->newQuery();

    if ($request->has(\'searchTerm\') && $term != \'\' && $term != null) {
        $details->where(function ($query) use ($term) {
            $query->where(\'details_name\', \'LIKE\', \'%\' . $term . \'%\')
                ->orWhere(\'details\', \'LIKE\', \'%\' . $term . \'%\');
        });
    }

    if ($request->has(\'topicId\') && $topic_id != \'\' && $topic_id != null) {
        $details->whereHas(
            \'topics\',
            function ($query) use ($topic_id) {
                $query->where(\'topics.id\', $topic_id);
            }
        );
    }

    $details = $details->get();

    if ($details) {
        return \\response()->json([
            \'details\' => $details,
            \'topics\' => $topics,
            \'status\' => \'success\',
        ], 200);
    } else {
        return \\response()->json([
            \'status\' => \'error\',
            \'message\' => \'Something went wrong. Please try again.\',
        ], 200);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc472500000000493a0c86";}";s:4:"hash";s:44:"3lloneXOkcWYfuQh0D7unNiB1TUKcqvHt7m6UWJTn5A=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::xUwoHtQdZ5ML6aYn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ONyZ1vdWAJucP57e' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/test-file-upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:1459:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1239:"function (\\Illuminate\\Http\\Request $request) {

    if ($request->hasFile(\'files_images\')) {

        $allowedfileExtension = [\'pdf\', \'jpg\', \'png\', \'gif\', \'bmp\', \'docx\', \'txt\'];
        $files = $request->file(\'files_images\');

        foreach ($files as $file) {
            $filename = $file->getClientOriginalName();
            $extension = $file->getClientOriginalExtension();
            $check = \\in_array($extension, $allowedfileExtension);
            $filename_without_ext = \\pathinfo($filename, PATHINFO_FILENAME);

            // return $filename;

            if ($check) {
                $filename = $file->storeAs(\'files_images\', $filename_without_ext . \'_\' . \\Illuminate\\Support\\Str::random(5) . \'.\' .  $extension, \'public\');
                if ($filename) {
                    $stored_filenames[] = $filename;
                }
            } else {
                return \\response()->json([
                    \'status\' => \'error\',
                    \'message\' => \'File extension not allowed.\',
                ], 200);
            }
        }

        return \\response()->json([
            \'status\' => \'success ends.\',
        ], 200);
    }

    return \\response()->json([
        \'status\' => \'ZXZX\',
    ], 200);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000005ddc44db00000000493a0c86";}";s:4:"hash";s:44:"nZ8LmJoRap2eyTPnQz8Il5FzOAdavfEjWMq4Bn31UDE=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ONyZ1vdWAJucP57e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qjd0cqp5SsLL9otj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{path}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::qjd0cqp5SsLL9otj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'react.index',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
        'path' => '([A-z\\d\\-\\/_.]+)?',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
