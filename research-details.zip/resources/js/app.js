import jQuery from 'jquery';
import '@popperjs/core';
import bootstrap from 'bootstrap';

window.$ = window.jQuery = jQuery;

require('select2');