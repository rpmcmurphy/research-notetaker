const BASE_URL = 'http://petero45.sg-host.com/';

export {
    BASE_URL
}