import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Row, Col, Button } from 'react-bootstrap';
import Form from 'react-bootstrap/Form';
import Select from 'react-select';

import detailsApi from '../api/details';

import SpinnerComponent from '../common/SpinnerComponent';
import axios from 'axios';

class SimpleReactFileUpload extends React.Component {

    constructor(props) {

        super(props);

        this.state = {
            file: null
        }

        this.onFormSubmit = this.onFormSubmit.bind(this)
        this.onChange = this.onChange.bind(this)
        this.fileUpload = this.fileUpload.bind(this)
    }

    onFormSubmit(e) {
        e.preventDefault() 
        this.fileUpload(this.state.file).then((response) => {
            console.log(response.data);
        })
    }

    fileToDataURL(file) {
        var reader = new FileReader()
        return new Promise(function (resolve, reject) {
            reader.onload = function (event) {
                resolve(event.target.result)
            }
            reader.readAsDataURL(file)
        })
    }

    onChange(e) {

        // const files = [];
        const files = Array.from(e.target.files).map(file => {
            console.log(file);
            // files.push(file);

            this.fileToDataURL(file).then(dataURL => {
                console.log(dataURL);
            });

            // const formData = new FormData();
            // formData.append("file", file);
        });

        console.log(files);

        // console.log(e.target.files[0]);
        this.setState({ file: files })
    }

    fileUpload(file) {
        const url = 'http://petero45.sg-host.com/api/test-file-upload';
        const formData = new FormData();
        formData.append('files_images', file)
        const config = {
            headers: {
                'content-type': 'multipart/form-data'
            }
        }
        return axios.post(url, formData, config);
    }

    render() {
        return (
            <form onSubmit={this.onFormSubmit}>
                <h1>File Upload</h1>
                <input type="file" multiple onChange={this.onChange} />
                <button type="submit">Upload</button>
            </form>
        )
    }
}

function AddDetailsComponent() {
    const [allTopics, setAllTopics] = useState([]);
    const [detailName, setDetailName] = useState("");
    const [details, setDetails] = useState("");
    const [topicIds, setTopicIds] = useState([]);
    const [isAdding, setIsAdding] = useState(false);
    const [error, setError] = useState(false);
    const [errorType, setErrorType] = useState("");
    const [message, setMessage] = useState("");

    const navigate = useNavigate();

    useEffect(() => {
        let active = true;

        const fetchTopics = async () => {
            try {
                const response = await detailsApi.getAllReactSelectTopics();
                if (!active) { return }
                setAllTopics(response.data.data);
            } catch (error) {
                console.log(error);
            }
        };

        fetchTopics();
        return () => { active = false }

    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();

        if (detailName != null && detailName != "" && details != null && details != "") {
            setIsAdding(true);

            let topicIdsMapped = [];
            if(topicIds.length != 0) {
                topicIds.map(async (topicId) => {
                    topicIdsMapped.push(topicId.value);
                });
            }

            const addNewDetail = async () => {
                try {
                    const response = await detailsApi.addDetail(detailName, details, topicIdsMapped);

                    if (response.data.status === 'success') {
                        setMessage(response.data.message);
                        setDetailName("");
                        setDetails("");
                        setTopicIds([]);
                        setIsAdding(false);

                        navigate("/details", { state: { message: response.data.message } });
                    } else {
                        setIsAdding(false);
                        setError(true);
                        setErrorType(response.data.type);
                        setMessage(response.data.message);
                    }

                } catch (error) {
                    console.log('error', error);
                }
            };

            addNewDetail();
        } else {
            alert("Please add a detail name and some details!");
        }
    };

    const axiosApi = axios.create({
        baseURL: "http://petero45.sg-host.com/api/",
        headers: {
            "Content-type": "application/json"
        }
    });

    return (
        <Row>
            <Col>
                <Row>
                    <Col md={6}>
                        <h5>Add Topic</h5>
                    </Col>
                </Row>
                <Row>
                    <Col md={6}>
                        {
                            isAdding && <SpinnerComponent />
                        }
                        {
                            (error && message && errorType != 'validation') && <div className="alert alert-danger">{message}</div>
                        }
                        {
                            errorType == 'validation' && <ul className="list-unstyled">
                                {
                                    message && message.map((item, index) => {
                                        return <li className="alert alert-danger" key={index}>{item}</li>
                                    })
                                }
                            </ul>
                        }
                    </Col>
                </Row>
                <Row>
                    <Col md={6}>
                        <Form>
                            <Row className="mb-3">
                                <Form.Group as={Col} controlId="formDetailName">
                                    <Form.Label>Detail name</Form.Label>
                                    <Form.Control value={detailName} onChange={(e) => setDetailName(e.target.value)} type="text" placeholder="Enter detail name" />
                                </Form.Group>
                            </Row>
                            <Row className="mb-3">
                                <Form.Group as={Col} controlId="formTopics">
                                    {
                                        allTopics.length > 0 && <Select isMulti options={allTopics} onChange={(selectedOption) => setTopicIds(selectedOption)} />
                                    }

                                </Form.Group>
                            </Row>
                            <Row className="mb-3">
                                <Form.Group className="mb-3" controlId="formDetails">
                                    <Form.Label>Details</Form.Label>
                                    <Form.Control as="textarea" rows={3} value={details} onChange={(e) => setDetails(e.target.value)}  placeholder="Add some details" />
                                </Form.Group>
                            </Row>
                            <Row>
                                <Form.Group as={Col}>
                                    <Button variant="primary" type="submit" onClick={handleSubmit}>
                                        Submit
                                    </Button>
                                </Form.Group>
                            </Row>
                        </Form>
                    </Col>
                </Row>
            </Col>
            <Col>
                <Row>
                    <Col md={6}>
                        <SimpleReactFileUpload />
                    </Col>
                </Row>
            </Col>
        </Row>
    )
}

export default AddDetailsComponent;