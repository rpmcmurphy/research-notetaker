import React from 'react';
import { Row, Col } from 'react-bootstrap';

const NotFoundComponent = () => {
    return (
        <Row>
            <Col>
                <h5>Nothing Found.</h5>
            </Col>
        </Row>
    );
};

export default NotFoundComponent;