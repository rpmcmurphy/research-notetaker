@extends('layouts.react')

@section('title', 'Research notetaker')

@section('content')
    <div id="root"></div>
@endsection